# Real Telegram Mini App (Ready)

This repository contains a Telegram Mini App (frontend) + Express backend + Admin panel.
Set environment variables (see .env.example) and deploy to a server (Render, Heroku) or adapt for Vercel.
