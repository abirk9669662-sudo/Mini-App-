const tg = window.Telegram?.WebApp || {};
try{ tg.expand(); }catch(e){}
const user = tg.initDataUnsafe?.user || { id: 0, first_name: 'Guest' };
document.getElementById('username').innerText = user.first_name || 'Guest';
document.getElementById('inviteLink').value = `https://t.me/YourBot?start=${user.id}`;

async function sendToServer(payload){
  payload.userId = user.id;
  payload.name = user.first_name;
  payload.username = user.username || '';
  await fetch('/api/action', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
}

function completeTask(type, url, amount){
  sendToServer({ action: type, amount, url });
  window.open(url, '_blank');
  const b = document.getElementById('balance');
  b.innerText = Number(b.innerText || 0) + Number(amount || 0);
  if(type === 'ad'){
    document.getElementById('todayAds').innerText = Number(document.getElementById('todayAds').innerText || 0) + 1;
    document.getElementById('totalAds').innerText = Number(document.getElementById('totalAds').innerText || 0) + 1;
  }
  document.getElementById('totalIncome').innerText = Number(document.getElementById('totalIncome').innerText || 0) + Number(amount || 0);
}

function withdraw(){
  const amount = Number(prompt('Enter withdraw amount (min 500)'));
  const number = document.getElementById('withdrawNumber').value;
  const method = document.getElementById('withdrawMethod').value;
  if(!amount || amount < 500){ alert('Minimum 500 Tk'); return; }
  if(!number){ alert('Enter Bkash/Nagad number'); return; }
  sendToServer({ action:'withdraw', amount, method, number });
  document.getElementById('balance').innerText = Number(document.getElementById('balance').innerText || 0) - amount;
  alert('Withdraw requested');
}
