import express from 'express';
import mongoose from 'mongoose';
import fetch from 'node-fetch';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import path from 'path';
dotenv.config();

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(process.cwd(),'public')));
app.use('/admin', express.static(path.join(process.cwd(),'admin')));

// Models
import User from './models/User.js';
import Withdraw from './models/Withdraw.js';

async function start(){
  await mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser:true, useUnifiedTopology:true });
  const TELEGRAM_API = `https://api.telegram.org/bot${process.env.BOT_TOKEN}`;

  app.post('/api/action', async (req,res)=>{
    try{
      const { action, amount, url, method, number, userId, name, username } = req.body;
      if(!userId) return res.status(400).json({ error: 'userId required' });
      let user = await User.findOne({ telegramId: userId });
      if(!user){
        user = await User.create({ telegramId:userId, firstName:name, username:username||'' });
      }
      if(action === 'ad'){
        user.todayAds += 1;
        user.totalAds += 1;
        const a = Number(amount||5);
        user.balance += a;
        user.totalIncome += a;
        await user.save();
      } else if(action === 'telegram' || action === 'youtube'){
        const a = Number(amount||0);
        user.balance += a;
        user.totalIncome += a;
        await user.save();
      } else if(action === 'referral'){
        user.balance += 40;
        user.totalIncome += 40;
        user.totalRefer += 1;
        await user.save();
      } else if(action === 'withdraw'){
        const amt = Number(amount||0);
        if(amt < 500) return res.status(400).json({ error: 'min withdraw 500' });
        if(user.balance < amt) return res.status(400).json({ error: 'insufficient balance' });
        user.balance -= amt;
        await user.save();
        const wr = await Withdraw.create({ userId:user.telegramId, amount:amt, method, number });
        // notify user
        await fetch(`${TELEGRAM_API}/sendMessage`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ chat_id: user.telegramId, text: `✅ Withdraw request received: ${amt} Tk via ${method} to ${number}. Request ID: ${wr._id}` })
        });
        if(process.env.ADMIN_CHAT_ID){
          await fetch(`${TELEGRAM_API}/sendMessage`, {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ chat_id: process.env.ADMIN_CHAT_ID, text: `Withdraw request: User ${user.telegramId} - ${amt} Tk via ${method} to ${number}. ID: ${wr._id}` })
          });
        }
      }
      return res.json({ success:true });
    }catch(err){
      console.error(err);
      return res.status(500).json({ error:'server error' });
    }
  });

  function adminAuth(req,res,next){
    const pass = req.headers['x-admin-pass'] || req.query.pass;
    if(!pass || pass !== process.env.ADMIN_PASS) return res.status(401).json({ error:'unauthorized' });
    next();
  }

  app.get('/api/admin/users', adminAuth, async (req,res)=>{
    const users = await User.find().sort({ createdAt:-1 }).lean();
    res.json(users);
  });

  app.get('/api/admin/withdraws', adminAuth, async (req,res)=>{
    const ws = await Withdraw.find().sort({ createdAt:-1 }).lean();
    res.json(ws);
  });

  app.post('/api/admin/withdraws/:id/approve', adminAuth, async (req,res)=>{
    const id = req.params.id;
    const wr = await Withdraw.findById(id);
    if(!wr) return res.status(404).json({ error:'not found' });
    wr.status = 'approved';
    wr.processedAt = new Date();
    await wr.save();
    if(process.env.BOT_TOKEN){
      await fetch(`https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ chat_id: wr.userId, text: `✅ Your withdraw ${wr._id} for ${wr.amount} Tk has been approved.` })
      });
      if(process.env.ADMIN_CHAT_ID){
        await fetch(`https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ chat_id: process.env.ADMIN_CHAT_ID, text: `✅ Approved withdraw ${wr._id} for user ${wr.userId} (${wr.amount} Tk).` })
        });
      }
    }
    res.json({ success:true });
  });

  app.post('/api/admin/withdraws/:id/reject', adminAuth, async (req,res)=>{
    const id = req.params.id;
    const wr = await Withdraw.findById(id);
    if(!wr) return res.status(404).json({ error:'not found' });
    wr.status = 'rejected';
    wr.processedAt = new Date();
    await wr.save();
    if(process.env.BOT_TOKEN){
      await fetch(`https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ chat_id: wr.userId, text: `❌ Your withdraw ${wr._id} for ${wr.amount} Tk has been rejected.` })
      });
    }
    res.json({ success:true });
  });

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, ()=>console.log('Server running on', PORT));
}

start().catch(err=>{ console.error(err); process.exit(1); });
