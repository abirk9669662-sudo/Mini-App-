async function loadUsers(){
  const pass = document.getElementById('apass').value;
  const res = await fetch('/api/admin/users?pass='+encodeURIComponent(pass));
  const data = await res.json();
  document.getElementById('users').innerText = JSON.stringify(data, null, 2);
}
async function loadWithdraws(){
  const pass = document.getElementById('apass').value;
  const res = await fetch('/api/admin/withdraws?pass='+encodeURIComponent(pass));
  const data = await res.json();
  document.getElementById('withdraws').innerText = JSON.stringify(data, null, 2);
}
