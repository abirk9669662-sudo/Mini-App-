import mongoose from 'mongoose';
const withdrawSchema = new mongoose.Schema({
  userId: Number,
  amount: Number,
  method: String,
  number: String,
  status: { type: String, enum: ['pending','approved','rejected'], default: 'pending' },
  createdAt: { type: Date, default: Date.now },
  processedAt: Date
});
export default mongoose.models.Withdraw || mongoose.model('Withdraw', withdrawSchema);
