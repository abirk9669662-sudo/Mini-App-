import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({
  telegramId: { type: Number, unique: true, required: true },
  firstName: String,
  username: String,
  balance: { type: Number, default: 0 },
  todayAds: { type: Number, default: 0 },
  totalAds: { type: Number, default: 0 },
  totalIncome: { type: Number, default: 0 },
  totalRefer: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});
export default mongoose.models.User || mongoose.model('User', userSchema);
